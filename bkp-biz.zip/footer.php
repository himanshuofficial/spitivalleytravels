  <!-- fotter starts-->

  <section id="footer">
  <div class="container">
  <div class="row">
    <div class="col-md-3">
    <ul>
      <li class="hvr-icon-buzz-out"><a href="#" data-toggle="modal" data-target="#formModal">Best Leh Ladakh Holiday Packages</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Holidays In Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Holiday Trip To Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Honeymoon Packages Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Packages To Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Tourism Of Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Traveling In Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Trip For Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Holidays Package</a></li>
    </ul>
    </div>

    <div class="col-md-3">
    <ul>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Packages For Couple</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Tourism Honeymoon Packages</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Trip Planner</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Best Leh Ladakh Honeymoon Packages</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Holidays To Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Honeymoon At Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Packages In Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Package Tours For Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Tour Packages In Leh Ladakh</a></li>
    </ul>
    </div>
    
    <div class="col-md-3">
    <ul>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Travel In Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Trips To Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Holiday Travels</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Package Tours</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Tour Packages For Couple</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Leh Ladakh Vacations</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Best Leh Ladakh Tour Packages</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Holiday To Leh Ladakh</a></li>
      <li class="hvr-icon-buzz-out"><a href="#"data-toggle="modal" data-target="#formModal">Honeymoon Packages Of Leh Ladakh</a></li>
    </ul>
    </div>
    
    
    <div class="col-md-3">
    <ul>
	<h2>Contact</h2>
      <li class="hvr-icon-buzz-out">Mehta Villa , Ground Floor, Upper Khalini Chowk- Shimla (171002) </li>
      <li class="hvr-icon-buzz-out">91-7591801490 </li>
      <li class="hvr-icon-buzz-out">lehladakhbiz@gmail.com</li>
      <li class="hvr-icon-buzz-out">PAN NO – AAJFH9247B</li>
      <li class="hvr-icon-buzz-out">Registration No. 11-935/2016-DTO-SML-602</li>

    </ul>
    </div>
    

  </div>
  </div>
  </section>
  <!-- fotter ends -->

  <!-- fottercaption starts-->
  <section id="caption">
  <div class="container">
  <div class="row">
    <div class="footer-left">
   
    </div>
    
  </div>
  </div>
  </section>
  <!-- fottercaption ends-->

  <!-- MODEL -->
  <div class="mymodal">
  <div class="modal modal1 fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title heding" id="exampleModalLabel">Get Free Tour Plan</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post" autocomplete="off">
            <div class="form-group former">
              <input type="text" class="form-control" id="name" name="name" pattern="[a-zA-Z\s]+" placeholder="Full Name" required="true">
            </div>

            <div class="form-group former">
              <input type="email" class="form-control" name="email" id="email" title="Please Enter Your Valid Phone No." placeholder="Email Id." required="true">
            </div>
             <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="contact" pattern="[0-9]{1}[0-9]{9}" title="Please Enter Your Valid Phone No." class="form-control" id="contact" placeholder="Contact No." required="true">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="duration" class="form-control" id="duration" placeholder="Duration"> -->
                  <select name="duration" class="form-control" id="duration" required="true" >
                    <option selected="selected" value="">Duration</option>
                 
                   <option value="4">4 Nights/5 Days</option>
                   <option value="5">5 Nights/6 Days</option>
                   <option value="6">6 Nights/7 Days</option>
                   <option value="7">7 Nights/8 Days</option>
                   <option value="8">8 Nights/9 Days</option>
                   <option value="9">9 Nights/10 Days</option>
                   <option value="10">10 Nights/11 Days</option>
                   <option value="11">11 Nights/12 Days</option>
                   <option value="12">12 Nights/13 Days</option>
                   <option value="13">13 Nights/14 Days</option>
                   <option value="14">14 Nights/15 Days</option>
                   <option value="15">More than 15 Days</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="date" readonly="" class="form-control"  id="datepicker2" required="true" placeholder="Travel Date">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="number" class="form-control" id="Adults" placeholder="No. of Adults"> -->
                   <select name="adult" class="form-control" id="adult" required="true" >
                    <option selected="selected" value="">No. of Adults</option>
                   <option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="Group">Group</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="form-group">
              <textarea class="form-control former" id="message" placeholder="Your Message" name="message"></textarea>
            </div>

            <center><button type="submit" name="submit" class="btn btn-plan hvr-ripple-out">Submit</button>
            </center>
          </form>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!-- MODEL -->
  <div class="whtapp-icon hidden-lg hidden-md hidden-sm">
          <div class="whtapp-box"> <a class="" href="https://wa.me/918353010033?text=I'm%20interested%20in%20your%20package"><i class="fa fa-whatsapp"></i>
</a> </div>
		  
        </div>
		
<div class="section_mobile  hidden-lg hidden-md hidden-sm">
  <div class="inner_mobile">
    
      <div class="col-md-12">
	  <a class="_btn_bm" href="tel:+91-7591801490"> 
        <div class="col-md-3 p-0 col-3 col-xs-3">
          <div class="_col_m"> <i class="fa fa-phone fa-1x"></i> </div>
		  
        </div>
		</a>
		
        <div class="col-md-9 p-0 col-xs-6">
		<a class="" href="" data-toggle="modal" data-target="#formModal"> 
          <div class="_col_bm">
            <button type="button" class="_btn_bm"   style="font-size: 16px;color: #000 ;">SEND ENQUIRY</button>
          </div>
		  </a>
        </div>
     
    </div>
  </div>
</div>


<!-- Global site tag (gtag.js) - Google Ads: 756650446 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-756650446"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-756650446');
</script>





<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
  
<script type="text/javascript">
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
            var date = new Date();
            var currentMonth = date.getMonth();
            var currentDate = date.getDate();
            var currentYear = date.getFullYear();
            $('#datepicker').datepicker({
            minDate: new Date(currentYear, currentMonth, currentDate)
            });

            $('#datepicker2').datepicker({
            minDate: new Date(currentYear, currentMonth, currentDate)
            });

  })
</script>

</body>

</html>