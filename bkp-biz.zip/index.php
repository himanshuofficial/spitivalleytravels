<?php include('header.php');?>
  <!-- header ends -->

  <!-- query starts-->
  <section id="slider">
  <div class="container">
  <div class="row">
      <div class="col-md-4">
      <!-- queryform starts -->
        <div class="query">
        <h1>Get Free Tour Plan</h1>

          <form action="" method="POST"  autocomplete="off">
            <div class="form-group">
              <input type="text" class="form-control" id="name" name="name" pattern="[a-zA-Z\s]+" placeholder="Full Name" required="true">
            </div>

            <div class="form-group">
              <input type="email" class="form-control" name="email" id="email" title="Please Enter Your Valid Phone No." placeholder="Email Id." required="true">
            </div>
             <div class="row">
            <div class=" col-sm-6">
                <div class="form-group">
                  <input type="number" name="contact" pattern="[0-9]{1}[0-9]{9}" title="Please Enter Your Valid Phone No." class="form-control" id="contact" placeholder="Contact No." required="true">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group">
                  <!-- <input type="duration" class="form-control" id="duration" placeholder="Duration"> -->
                  <select name="duration" class="form-control" id="duration" required="true" >
                    <option selected="selected" disabled>Duration</option>
                   <option value="4">4 Nights/5 Days</option>
                   <option value="5">5 Nights/6 Days</option>
                   <option value="6">6 Nights/7 Days</option>
                   <option value="7">7 Nights/8 Days</option>
                   <option value="8">8 Nights/9 Days</option>
                   <option value="9">9 Nights/10 Days</option>
                   <option value="10">10 Nights/11 Days</option>
                   <option value="11">11 Nights/12 Days</option>
                   <option value="12">12 Nights/13 Days</option>
                   <option value="13">13 Nights/14 Days</option>
                   <option value="14">14 Nights/15 Days</option>
                   <option value="15">More than 15 Days</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="row">
            <div class=" col-sm-6">
                <div class="form-group">
                  <input type="text" name="date" readonly="" class="form-control"  id="datepicker" required="true" placeholder="Travel Date">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group">
                  <!-- <input type="number" class="form-control" id="Adults" placeholder="No. of Adults"> -->
                    <select name="adult" class="form-control" id="adult" required="true" >
                    <option selected="selected" value="">No. of Adults</option>
                   <option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="Group">Group</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="form-group">
              <textarea class="form-control" id="message" placeholder="Your Message" name="message"></textarea>
            </div>

            <center><button type="submit" name="submit" class="btn btn-plan hvr-ripple-out">Submit</button>
            </center>
          </form>

        </div>
      <!-- queryform ends --> 
      </div>

      <div class="col-md-8 hidden-xs">
        <div class="heading">
        <h3>LEH LADAKH TOUR PACKAGES</h3>
        <h5>Customized Tours from Trusted Local Agents At Lowest Prices</h5>
        </div>

      </div>

    </div>
    </div>
  </section>
  <!-- query ends-->


  <!-- our experties starts -->
  <section id="expert">
  <div class="container">
  <div class="row">

    <div class="col-md-2 bdr pad">
    <h2>Our Experties:</h2>
    </div>

    <div class="col-md-3 bdr pad">
      <div class="iconset"><img src="images/icon1.png" alt="palm-tree"></div>
      <div class="icontext"> Best Rates in the Market<br>
      <span>Best Rates available</span></div>
    </div>

    <div class="col-md-3 bdr pad">
      <div class="iconset"><img src="images/icon2.png" alt="palm-tree"></div>
      <div class="icontext">Get Customized Packages<br>
      <span>Fill Form to Customize</span></div>
    </div>

    <div class="col-md-4 pad">
      <div class="iconset"><img src="images/icon3.png" alt="palm-tree"></div>
      <div class="icontext">24 * 7 Customer Support<br>
      <span>On Direct Sales Person Mobile Number</span></div>
    </div>

  </div>
  </div>
  </section>
  <!-- our experties ends -->

  <!-- packages starts -->
  <section id="packages">
  <div class="container">
  <div class="row">
      <!-- title -->
      <div class="col-lg-12">
      <div class="title">
      <h1>Leh Ladakh Tour Packages</h1>
      </div>
      </div>
      <!-- title -->
  </div>

  <!-- tourpackages starts -->
  <div class="row gapbt">
      <!-- package starts -->
      <div class="col-sm-4">
	  <a href="magical-ladakh-road-trip.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh1.jpg" alt="Magical Ladakh" width="100%">
			</div>
			<div class="tag"> 30% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
          <h1>Magical Ladakh with Road Trip</h1>
			</div>
			<p class="aa">INR <span class="myline">39,182  </span> &nbsp <span class="colorclass"> 27,400</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  09 Nights / 10 Days <span>02 nights Manali | 01night Sarchu | 03 nights Leh | 01 night Nubra | 01 Night Pangong | 01 Night Jispa |</span></p>
		
			<h2>Package Inclusions:</h2>
			<div class="mydivccolor div2">
			<ul style="list-style-type:disc;">
<li><p class="p2">Assistance upon arrival.</p></li>
<li><p class="p2">Traditional welcome in the Hotel with Welcome Drink (Hot Tea/Coffee /Kahwa)</p></li>
<li><p class="p2">Visit Manali, Sarchu, Leh, Nubra, Pangong, Jispa.</p></li>
<li><p class="p2">All Sightseeing as per itinerary by Innova Cab.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">pick up from Chandigarh/Delhi and drop at Chandigarh/Delhi by 01 Ac Innova.</p></li>
<li><p class="p2">09 Nights Accommodation on double sharing basis with 09 Breakfast and 09 Dinner.</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="magical-ladakh-road-trip.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
	  </a>
      </div>
      <!-- package ends -->


      <!-- package starts -->
      <div class="col-sm-4">
	  <a href="magical-ladakh.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh2.jpg" alt="Magical Ladakh" width="100%">
			</div>
			<div class="tag"> 40% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
            <h1>Magical Ladakh</h1>
			</div>
			<p class="aa">INR <span class="myline">32,064 </span> &nbsp <span class="colorclass"> 19,200</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  07Nights / 8Days  <span>02 nights Leh | 02nights Nubra|3Nights Leh | (Day Excursion from Pangong Lake)|</span></p>
		
			<h2>Package Inclusions:</h2>
			<div class="mydivccolor div2">
			<ul style="list-style-type:disc;">
<li><p class="p2"><strong>Leh:</strong> Gurudwara | Hall of fame | Sangam | Magnetic Hill | Shanti Stupa | Leh Palace | Sindhu Ghat | Spituk monestery</p></li>
<li><p class="p2">Visit Leh, Nubra, (Day Excursion From Pangong Lake)</p></li>
<li><p class="p2">All Sightseeing as per itinerary by Innova Cab.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">pick up from Chandigarh/Delhi and drop at Chandigarh/Delhi by 01 Ac Innova.</p></li>
<li><p class="p2">07 Nights Accommodation on double sharing basis with 07 Breakfast and 07 Dinner.</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="magical-ladakh.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
		</a>
	 </div>
      <!-- package ends -->

      <!-- package starts -->
      <div class="col-sm-4">
	  <a href="simply-ladakh.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh3.jpg" alt="Simply Ladakh" width="100%">
			</div>
			<div class="tag"> 45% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
            <h1>Simply Ladakh</h1>
			</div>
			<p class="aa">INR <span class="myline">32,032  </span> &nbsp <span class="colorclass"> 17,600</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  05 Nights / 06 Days <span>03 nights Leh | 01night Nubra | 01night Pangong | </span></p>
		
			<h2 >Package Inclusions:</h2>
			<div class="mydivccolor div3">
			<ul style="list-style-type:disc;">
<li><p class="p2">Leh : Gurudwara | Sangam | Pangong Lake | Spituk monestery | Hall of fame | Magnetic Hill Assistance </p></li>
<li><p class="p2">Nubra Valley : Khardungla Pass | Diskit monasteries </p></li>
<li><p class="p2">All Sightseeing as per itinerary by Innova Cab.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">Pick up from Leh and drop at Leh by 01 Ac Innova</p></li>
<li><p class="p2">05 Nights Accommodation on double sharing basis with 05 Breakfast and 05 Dinner.</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="simply-ladakh.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
	  </a>
      </div>
      <!-- package ends -->
  </div>

  <div class="row gapbt">
      <!-- package starts -->
      <div class="col-sm-4">
	  <a href="ladakh-with-tasomiriri.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh4.jpg" alt="Magical Ladakh with Tsomoriri" width="100%">
			</div>
			<div class="tag"> 35% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
            <h1>Magical Ladakh with Tso moriri</h1>
			</div>
			<p class="aa">INR <span class="myline">30,184 </span> &nbsp <span class="colorclass">19,600</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  06 Nights / 7 Days <span>03 nights Leh | 01night Nubra | 01night Pangong| 01night Tsomoriri</span></p>
		
			<h2 >Package Inclusions:</h2>
			<div class="mydivccolor div4">
			<ul style="list-style-type:disc;">
<li><p class="p2">Leh : Gurudwara | Sangam | Pangong Lake | Spituk monestery | Hall of fame | Magnetic Hill Assistance </p></li>
<li><p class="p2">Nubra Valley : Khardungla Pass | Diskit monasteries, Pangong, Tsomoriri</p></li>
<li><p class="p2">All Sightseeing as per itinerary by Innova Cab.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">Pick up from Leh and drop at Leh by 01 Ac Innova</p></li>
<li><p class="p2">06 Nights Accommodation on double sharing basis with 06 Breakfast and 06 Dinner.
</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="ladakh-with-tasomiriri.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
	  </a>
      </div>
      <!-- package ends -->

      <!-- package starts -->
      <div class="col-sm-4">
	  <a href="welcome-ladakh.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh5.jpg" alt="Welcome to Ladakh" width="100%">
			</div>
			<div class="tag"> 20% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
            <h1>Welcome to Ladakh</h1>
			</div>
			<p class="aa">INR <span class="myline">19875 </span> &nbsp <span class="colorclass"> 15,900</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  04 Nights / 05 Days <span>03 nights Leh | 01night Nubra</span></p>
		
			<h2 >Package Inclusions:</h2>
			<div class="mydivccolor div5">
			<ul style="list-style-type:disc;">
<li><p class="p2">•	Leh : Gurudwara | Spituk monestery | Hall of fame | Magnetic Hill Assistance </p></li>
<li><p class="p2">•	Nubra Valley : Khardungla Pass | Diskit monasteries</p></li>
<li><p class="p2">All Sightseeing as per itinerary by Innova Cab.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">Pick up from Leh and drop at Leh by 01 Ac Innova</p></li>
<li><p class="p2">04 Nights Accommodation on double sharing basis with 04 Breakfast and 04 Dinner.</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="welcome-ladakh.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
	  </a>
      </div>
      <!-- package ends -->

      <!-- package starts -->
      <div class="col-sm-4">
	   <a href="ladakh-bike.php">
      <div class="pack">
        <div class="packimage">
          <div class="hovereffect">
            <img src="images/packages/lehladakh6.jpg" alt="Discover Ladakh by Motor Bike" width="100%">
			</div>
			<div class="tag"> 45% off</div>
          <div class="packdetails">
		  <div align="left">
		  <div class="mybkgcol">
            <h1>Discover Ladakh by Motor Bike</h1>
			</div>
			<p class="aa">INR <span class="myline">48,048 </span> &nbsp <span class="colorclass"> 26,400</span>  Onwards </span></p>
			<div class="mypakage">
			
            <p class="p2">  06 Nights / 07 Days <span>03 nights Leh | 01night Nubra | 01night Pangong| 01night Tsomiriri</span></p>
		
			<h2 >Package Inclusions:</h2>
			<div class="mydivccolor div6">
			<ul style="list-style-type:disc;">
<li><p class="p2">Leh : Gurudwara | Sangam | Pangong Lake | Spituk monestery | Hall of fame | Magnetic Hill .</p></li>
<li><p class="p2">Nubra Valley : Khardungla Pass | Diskit monasteries, Pangong, Tsomoriri</p></li>
<li><p class="p2">All Sightseeing as per itinerary by Bullet.</p></li>
<li><p class="p2">01 Backup Cab.</p></li>
<li><p class="p2">01 Mechanic.</p></li>
<li><p class="p2">All hotel and transport taxes.</p></li>
<li><p class="p2">Pick up from Leh and drop at Leh.</p></li>
<li><p class="p2">06 Nights Accommodation on double sharing basis with 06 Breakfast and 06 Dinner.</p></li>
<li><p class="p2">Inner Line Permit.</p></li>
</ul>
          </div>
          </div>
          </div>
        
            <div class="packselect" align="left">
              
              <a href="ladakh-bike.php"><button type="submit"  class="btn btn-det hvr-blu-ripple-out">MORE DETAILS</button></a>
              <button type="submit" class="btn btn-enq hvr-ripple-out" data-toggle="modal" data-target="#formModal" data-whatever="@mdo">SEND ENQUIRY</button>
              
            </div>
          </div>
        </div>
      </div>
	  </a>
      </div>
      <!-- package ends -->
  </div>

  <!-- tourpackages starts -->
  </div>
  </section>
  <!-- packages starts -->

  <!-- more starts-->
  <section id="moreinfo">
  <div class="container">
  <div class="row">
      <div class="col-lg-12">
      </div>
  </div>
  </div>
  </section>
  <!-- more ends-->

<?php include('footer.php');?>