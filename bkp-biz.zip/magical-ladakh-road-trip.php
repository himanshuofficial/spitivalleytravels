<?php include('header.php');?>
  
      <div class="container">
      <div class="section-header">
	  <div class="mainheading">
        <h1 class="text-center">Magical Ladakh with Road Trip</h1>
		</div>
		<div class="row">
		
		<div class="col-sm-6">
				<div class="myimage">
				<img src="images\packages\lehladakh1.jpg">
				</div>
		</div>
		
		<div class="col-sm-6">
		 <div class="mymodal">
  
      <div class="modal-content">
        <div class="modal-header modal-header1">
  
          <h4 class="modal-title heding" id="exampleModalLabel">Get Free Tour Plan</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post" autocomplete="off">
            <div class="form-group former">
              <input type="text" class="form-control" id="name" name="name" pattern="[a-zA-Z\s]+" placeholder="Full Name" required="true">
            </div>

            <div class="form-group former">
              <input type="email" class="form-control" name="email" id="email" title="Please Enter Your Valid Phone No." placeholder="Email Id." required="true">
            </div>
             <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="contact" pattern="[0-9]{1}[0-9]{9}" title="Please Enter Your Valid Phone No." class="form-control" id="contact" placeholder="Contact No." required="true">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="duration" class="form-control" id="duration" placeholder="Duration"> -->
                  <select name="duration" class="form-control" id="duration" required="true" >
                    <option selected="selected" value="">Duration</option>
                 
                   <option value="4">4 Nights/5 Days</option>
                   <option value="5">5 Nights/6 Days</option>
                   <option value="6">6 Nights/7 Days</option>
                   <option value="7">7 Nights/8 Days</option>
                   <option value="8">8 Nights/9 Days</option>
                   <option value="9">9 Nights/10 Days</option>
                   <option value="10">10 Nights/11 Days</option>
                   <option value="11">11 Nights/12 Days</option>
                   <option value="12">12 Nights/13 Days</option>
                   <option value="13">13 Nights/14 Days</option>
                   <option value="14">14 Nights/15 Days</option>
                   <option value="15">More than 15 Days</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="date" readonly="" class="form-control"  id="datepicker2" required="true" placeholder="Travel Date">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="number" class="form-control" id="Adults" placeholder="No. of Adults"> -->
                    <select name="adult" class="form-control" id="adult" required="true" >
                    <option selected="selected" value="">No. of Adults</option>
                   <option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="Group">Group</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="form-group">
              <textarea class="form-control former" id="message" placeholder="Your Message" name="message"></textarea>
            </div>

            <center><button type="submit" name="submit" class="btn btn-plan hvr-ripple-out">Submit</button>
            </center>
          </form>
        </div>
      </div>
   
  </div>
 
		</div>
		</div>
		<br>
<div class="myclass"> 
<div class="myheading">
				<h5 class="colorb" >Magical Ladakh with Road Trip</h5>		
				<h5>09 Nights and 10 Days</h5>
				<h5> INR <span class="myline"> 39,182</span> &nbsp 27,400 Onwards <span class="colorr">(30% off)</span> </h5>
				</div>
				<div class="departure-cnt">
				<b> Group Departure dates:-</b><br/>
- 27th July 2019<br/>
- 10th August 2019<br/>
- 21st August 2019<br/>
- 31st August 2019<br/>
- 14th September 2019<br/>
- 27th September 2019<br/>
- 04th October 2019<br/>
- 18th October 2019
</div>
				
<h2>Package Inclusions:</h2>		
<p>•	Assistance upon arrival.</p>
<p>•	Traditional welcome in the Hotel with Welcome Drink (Hot Tea/Coffee /Kahwa)</p>
<p>•	Visit Manali, Sarchu, Leh, Nubra, Pangong, Jispa</p>
<p>•	All Sightseeing as per itinerary by Innova Cab</p>
<p>•	All hotel and transport taxes.</p>
<p>•	pick up from Chandigarh/Delhi and drop at Chandigarh/Delhi by 01 Ac Innova</p>
<p>•	09 Nights Accommodation on double sharing basis with 09 Breakfast and 09 Dinner..</p>
<p>•	Inner Line Permit.</p>

<h4>Day 01: Delhi to Manali </h4>
<p>
On arrival at Delhi Airport/Railway Station you will be met, assisted and drive and transfer
to Manali. Overnight stay in Manali.
</p>

<h4>DAY 02: MANALI TO SARCHU (222 KMS)</h4>
<p> 
Today we start our journey to Leh Stopping at Sarchu for a night. Today we cross
Rohtang Pass (3978 m), Keylong (3350 m), Baralacha Pass (4890m) with overnight
stopover at Sarchu (4253 m), border of the states of Himachal Pradesh (Lahaul) and
Jammu & Kashmir (Ladakh). Upon arrival in Sarchu we check in at our tented campsitefor overnight stay.
</p>

<h4>DAY 03: SARCHU TO LEH (255 KMS) </h4>
<p>
Leave for Leh by early morning, through Nakeela and Lachangla Pass 16,617 ft. Lunch
at Pang. After Lunch drive to Leh passing through Skyangchu Thang (Biggest and
Highest Plateau on Earth on Stretch of 42 Kms), <strong>Taklang La Pass
17,5856ft(2nd highest motorable road in the worls)</strong> and Indus Valley. Upon arrival in leh you’ll met by our representative and check in at our Hotel. Overnight in hotel.</p>

<h4>DAY 04: LEH – LOCAL SIGHTSEEING </h4>
<p>
After breakfast drive to explore the beauty of Shanti Stupa, Leh palace and market .
<strong>Shanti Stupa</strong>:- Shanti stupa was founded in 1985 sponsored by Japanese for world
peace. It was inaugurated by His holiness the 14th Dalai lama. Shanti stupa has a
spectacular view od Leh city and Stok glacier.
<strong>Leh Palace</strong>:-The Leh Palace known as ‘Lachen Palkhar’ was built by Singay Namgyal,
around the beginning of 17th century AD. The nine-storey Palace is now deserted, and
archeological survey of India has taken up the renovation work.Over night in hotel.
</p>

<h4>DAY 05: LEH–NUBRA VALLEY VIA KHARDUNG LA 18,380 FT. (120
KMS / 4 – 5 HRS) </h4>
<p>
After breakfast we drive to Nubra Valley. The road journey from Leh to Nubra Valley
passes over <strong>Khardung La</strong> (The Highest Motorable Road In The World) at 5,602 Mtrs / 18,380 ft, around 39 km from Leh. From the pass, one can see all the way south over the
Indus valley to seemingly endless peaks and ridges of the Zanskar range, and north to
the giants of the Saser massif. Nubra Valley is popularly known as Ldumra or the valley
of flowers. It is situated in the north of Ladakh between the Karakoram and Ladakh
ranges of the Himalayas. The average altitude of the valley is 10,000 Ft. above sea level.
Upon arrival in Nubra we check in at our Camp / Hotel in Hunder for Overnight stay. In
the evening you can walk around the tiny villages to see how the locals live in this part
of the world. A visit to a Ladakhi home can be arranged. Overnight Stay at the Camp or
Hotel.
</p>

<h4>DAY 06: NUBRA VALLEY – PANGONG LAKE – 13,930 FT. (275 KMS / 7
- 8 HRS ) </h4>
<p>
After Breakfast Full day trip, after early morning breakfast we leave for <strong>Pangong
Lake</strong> through <strong>Changla pass (17,586 ft) world third highest motorable road in the
world.</strong> After 2 hrs of drive you reach to Changla pass, stop for a short period for
photography. Drive ascending towards Pangong reach Tangtse where you can relax for
a cup of tea/ coffee. Leaving Tangtse for Pangong you pass through few small villages of
Changthang and finally you can have a sudden view of the Pangong lake situated at
13,930 feet. This famous high altitude Lake of Pangong is 5- 8Kms wide and over 140
Kms long with 30 % in India and 70% in China. This large, serene lake forms a brilliant
color variation including deep blue, dark green, turquoise,etc. Dinner and overnight in
camp.
</p>
<h4>DAY 07: PANGONG LAKE TO LEH (180 KMS / 5-7 HRS)</h4> <p>Morning at leisure to explore the beauty of lake and later we drive back to leh. Drive
further to Leh and check in at our hotel for Overnight.
In the evening you can stroll around the market place for some last minute souvenir
shopping.
</p>

<h4>DAY 08: LEH TO Jispa (335 KMS) </h4>
<p>
Leave for Serchu by early morning, through Nakeela and Lachangla Pass 16,617 ft.
Lunch at Pang , passing through Skyangchu Thang (Biggest and Highest Plateau on
Earth on Stretch of 42 Kms), Taklang La Pass 17,5856ft(2nd highest motorable road in the worls) and Indus Valley. Upon arrival in Sarchu you’ll met by our representative and
check in at our Hotel. Overnight in Hotel .
</p>

<h4>DAY 09: Jispa TO MANALI (92 KMS) </h4>
<p>
Today we start our journey to Manali . Dinner and overnight stay in Manali.</p>

<h4>Day 10: Manali to Delhi DROP </h4>
<p>
After the breakfast checkout the hotel and transfer to Delhi. Drop at Delhi Airport /Railway station for homeward journey with sweet memories
</p>
<br>
</div>		
      <div class="row">
        <div class="col-sm-12 myclass1">
          <h2 class="text-center">Popular Tours</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="magical-ladakh.php"><img class="img-fluid" src="images\packages\lehladakh2.jpg" alt="Magical ladakh"> <span>7N/8D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="magical-ladakh.php">Magical ladakh</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="magical-ladakh.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
		
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-bike.php"><img class="img-fluid" src="images\packages\lehladakh6.jpg" alt="Ladakh by Motor Bike"> <span>6N/7D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="ladakh-bike.php">Ladakh by Motor Bike</a></strong></h5>

            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-bike.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
		  
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-with-tasomiriri.php"><img class="img-fluid" src="images\packages\lehladakh4.jpg" alt="Ladakh with tasomiriri"> <span>6N/7D</span> </a> </div>
           <div align="center" class="package-content">
              <h5><strong><a href="ladakh-with-tasomiriri.php">Ladakh with tasomiriri</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-with-tasomiriri.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
      
      <div class="col-md-3 col-sm-6">
        <div class="single-package">
          <div class="package-image"> <a href="simply-ladakh.php"><img class="img-fluid" src="images\packages\lehladakh3.jpg" alt="Simply Ladakh"> <span>5N/6D</span> </a> </div>
          <div align="center" class="package-content">
            <h5><strong><a href="simply-ladakh.php">Simply Ladakh</a></strong></h5>
          </div>
							<div class="packselect" align="center">             
							 <a href="simply-ladakh.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
        </div>
    </div>
     </div>
    </div>
    </div>
  <section id="moreinfo">
  <div class="container">
  <div class="row">
      <div class="col-lg-12">
      </div>
  </div>
  </div>
  </section>
  <!-- more ends-->

<?php include('footer.php');?>