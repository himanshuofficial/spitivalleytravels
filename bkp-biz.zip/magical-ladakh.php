<?php include('header.php');?>
  
      <div class="container">
      <div class="section-header">
	  <div class="mainheading">
        <h1 class="text-center">Magical Ladakh</h1>
		</div>
		<div class="row">
		
		<div class="col-sm-6">
				<div class="myimage">
				<img src="images\packages\lehladakh2.jpg">
				</div>
		</div>
		
	<div class="col-sm-6">
		 <div class="mymodal">
  
      <div class="modal-content">
        <div class="modal-header modal-header1">
  
          <h4 class="modal-title heding" id="exampleModalLabel">Get Free Tour Plan</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post" autocomplete="off">
            <div class="form-group former">
              <input type="text" class="form-control" id="name" name="name" pattern="[a-zA-Z\s]+" placeholder="Full Name" required="true">
            </div>

            <div class="form-group former">
              <input type="email" class="form-control" name="email" id="email" title="Please Enter Your Valid Phone No." placeholder="Email Id." required="true">
            </div>
             <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="contact" pattern="[0-9]{1}[0-9]{9}" title="Please Enter Your Valid Phone No." class="form-control" id="contact" placeholder="Contact No." required="true">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="duration" class="form-control" id="duration" placeholder="Duration"> -->
                  <select name="duration" class="form-control" id="duration" required="true" >
                    <option selected="selected" value="">Duration</option>
               
                   <option value="4">4 Nights/5 Days</option>
                   <option value="5">5 Nights/6 Days</option>
                   <option value="6">6 Nights/7 Days</option>
                   <option value="7">7 Nights/8 Days</option>
                   <option value="8">8 Nights/9 Days</option>
                   <option value="9">9 Nights/10 Days</option>
                   <option value="10">10 Nights/11 Days</option>
                   <option value="11">11 Nights/12 Days</option>
                   <option value="12">12 Nights/13 Days</option>
                   <option value="13">13 Nights/14 Days</option>
                   <option value="14">14 Nights/15 Days</option>
                   <option value="15">More than 15 Days</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="date" readonly="" class="form-control"  id="datepicker2" required="true" placeholder="Travel Date">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="number" class="form-control" id="Adults" placeholder="No. of Adults"> -->
                    <select name="adult" class="form-control" id="adult" required="true" >
                    <option selected="selected" value="">No. of Adults</option>
                   <option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="Group">Group</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="form-group">
              <textarea class="form-control former" id="message" placeholder="Your Message" name="message"></textarea>
            </div>

            <center><button type="submit" name="submit" class="btn btn-plan hvr-ripple-out">Submit</button>
            </center>
          </form>
        </div>
      </div>
   
  </div>
 
		</div>
		
		</div>
		<br>
<div class="myclass">      
<div class="myheading">
				<h5 class="colorb" >Magical Ladakh</h5>		
				<h5>07 Nights and 08 Days</h5>
				<h5> INR <span class="myline"> 32,064  </span> &nbsp 19,200   Onwards <span class="colorr">(40% off)</span> </h5>
				</div>
				<div class="departure-cnt">
				<b> Group Departure dates:-</b><br/>
- 27th July 2019<br/>
- 10th August 2019<br/>
- 21st August 2019<br/>
- 31st August 2019<br/>
- 14th September 2019<br/>
- 27th September 2019<br/>
- 04th October 2019<br/>
- 18th October 2019
</div>
<h2>Package Inclusions:</h2>		
<p>•	<strong>Leh</strong>: Gurudwara | Hall of fame | Sangam | Magnetic Hill | Shanti Stupa | Leh Palace | Sindhu Ghat | Spituk monestery</p>
<p>•	Visit Leh, Nubra, (Day Excursion From Pangong Lake)</p>
<p>•	All Sightseeing as per itinerary by Innova Cab</p>
<p>•	All hotel and transport taxes.</p>
<p>•	pick up from Leh and drop at Leh by 01 Ac Innova.</p>
<p>•	07 Nights Accommodation on double sharing basis with 07 Breakfast and 07 Dinner.</p>
<p>•	Inner Line Permit.</p>

<h4>Day 01:- Arrive Leh:</h4>

<p>Early morning board flight to Leh. Upon arrival at the Leh Airport, you will be received by our driver and transferred to your hotel. Take lunch and relax. Since you are arriving at 11000 ft, we strongly recommend taking complete rest on the first day where you should not indulge yourself in any strenuous activity. Rest of the day is free to acclimatize to the high altitude of Leh. Dinner & Overnight at hotel.</p>

<h4>Day 02: Leh Local Sightseeing & Monastery Tour</h4>
<p>
Morning after breakfast, drive to Thiksey village, visit Thiksey monastery and later drive to Shey Village to visit Shey Palace and Gompa. Later visit Sindhu Ghat and return to hotel. Spend rest of the day at leisure.
</p>
<h4>
Day 03: Leh – Khardung La - Nubra Valley (140 Kms / Approx 05-06 Hrs)
</h4>
<p>
After breakfast, proceed to Nubra Valley via the World Highest Motorable road at 5602 m, the Khardungla pass (now second to Mana Pass in Uttarakhand). Lunch on way to Nubra. After reaching Nubra, check in at the camp and relax. Later in the evening, enjoy bonfire at the camp (subject to weather conditions) and take a walk in the vicinity of camp. Dinner and Overnight stay at the camp.
Note: The Khardung La pass may remain close till first week of May. In that case the tourist will do excursion to Khadung La and stay at Leh in place of Nubra Valley on day 03 & 04.
</p>

<h4>Day 04: Nubra Valley</h4>
<p>
After breakfast, proceed vist Diskit monastery, 500 years old Gompa located at an altitude of 3142 meters on the hilltop and witness impressive 106 feet long statue of the Jampa (Maitreya) Buddha facing the Shyok River. Afterwards, proceed to the White Sand Dunes at Hunder. You can enjoy the camel ride (On direct payment basis). Return to the camp and relax.Dinner and overnight stay at the camp.
</p>

<h4>DAY 05: Nubra to Pangong to Leh (280 Kms / Approx 09-10 Hrs Total)</h4>
<p>
After breakfast, leave for Pangong Lake at 14, 500 ft. via Agham & Shyok village and reach Pangong Lake. Pangong, the highest salt water lake in the world. Take in the breath-taking views and setting of the blue lake set amidst the lofty Himalaya Mountains. A popular location for many Bollywood movies, enjoy some unique moments and don’t forget to click some nice pictures. Later in the afternoon, start your journey towards leh and enjoy lunch enroute and reach leh by evening via ChanLa (17,350 ft. third highest motorable road in the world). Check in at the hotel and relax. Evening at your own leisure. Dinner & Overnight stay at hotel.
</p>

<h4>DAY 06: Day Free At Leisure (For Optional Activities)</h4>
<p>
Enjoy your breakfast and relax. Post lunch (on your own) visit Leh Palace and explore the local leh market for shopping. Later in the evening, visit Shanti Stupa for beautiful sunset view. One can also opt for any of the optional activities this day (Rafting / session with Oracle / visit to local ladakhi house with tea/cookies session). Return to hotel in the evening and spend the day at leisure. Dinner & Overnight stay at hotel.
</p>
<h4>
DAY 07: Leh: Excursion To Sham Valley (60 Kms/Approx 02 Hrs One Way</h4>
<p>
After breakfast, depart for the beautiful Sham valley tour. En route Visit Ladakh Hall of Fame, Magnetic Hill, Gurudwara Patthar Sahib and Confluence of Zanskar and Indus river. Return to hotel in the late afternoon and relax. Evening is free for leisure activities. Dinner & Overnight stay at Hotel.
</p>
<h4>
DAY 08: Departure from Leh:
</h4>
<p>
After breakfast, Depart to Leh airport to board the flight back for onward journey.
</p>
<br>
</div>		
      <div class="row">
        <div class="col-sm-12 myclass1">
          <h2 class="text-center">Popular Tours</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="magical-ladakh-road-trip.php"><img class="img-fluid" src="images\packages\lehladakh2.jpg" alt="Magical ladakh"> <span>9N/10D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="magical-ladakh-road-trip.php">Ladakh with Road Trip</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="magical-ladakh-road-trip.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
		
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-bike.php"><img class="img-fluid" src="images\packages\lehladakh6.jpg" alt="Ladakh by Motor Bike"> <span>6N/7D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="ladakh-bike.php">Ladakh by Motor Bike</a></strong></h5>

            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-bike.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
		  
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-with-tasomiriri.php"><img class="img-fluid" src="images\packages\lehladakh4.jpg" alt="Ladakh with tasomiriri"> <span>6N/7D</span> </a> </div>
           <div align="center" class="package-content">
              <h5><strong><a href="ladakh-with-tasomiriri.php">Ladakh with tasomiriri</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-with-tasomiriri.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
      
      <div class="col-md-3 col-sm-6">
        <div class="single-package">
          <div class="package-image"> <a href="simply-ladakh.php"><img class="img-fluid" src="images\packages\lehladakh3.jpg" alt="Simply Ladakh"> <span>5N/6D</span> </a> </div>
          <div align="center" class="package-content">
            <h5><strong><a href="simply-ladakh.php">Simply Ladakh</a></strong></h5>
          </div>
							<div class="packselect" align="center">             
							 <a href="simply-ladakh.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
        </div>
    </div>
     </div>
    </div>
    </div>
  <section id="moreinfo">
  <div class="container">
  <div class="row">
      <div class="col-lg-12">
      </div>
  </div>
  </div>
  </section>
  <!-- more ends-->

<?php include('footer.php');?>