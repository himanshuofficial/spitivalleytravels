<?php include('header.php');?>
  
      <div class="container">
      <div class="section-header">
	  <div class="mainheading">
        <h1 class="text-center">Simply Ladakh</h1>
		</div>
		<div class="row">
		
		<div class="col-sm-6">
				<div class="myimage">
				<img src="images\packages\lehladakh3.jpg">
				</div>
		</div>
		
		<div class="col-sm-6">
		 <div class="mymodal">
  
      <div class="modal-content">
        <div class="modal-header modal-header1">
  
          <h4 class="modal-title heding" id="exampleModalLabel">Get Free Tour Plan</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post" autocomplete="off">
            <div class="form-group former">
              <input type="text" class="form-control" id="name" name="name" pattern="[a-zA-Z\s]+" placeholder="Full Name" required="true">
            </div>

            <div class="form-group former">
              <input type="email" class="form-control" name="email" id="email" title="Please Enter Your Valid Phone No." placeholder="Email Id." required="true">
            </div>
             <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="contact" pattern="[0-9]{1}[0-9]{9}" title="Please Enter Your Valid Phone No." class="form-control" id="contact" placeholder="Contact No." required="true">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="duration" class="form-control" id="duration" placeholder="Duration"> -->
                  <select name="duration" class="form-control" id="duration" required="true" >
                    <option selected="selected" value="">Duration</option>
                 
                   <option value="4">4 Nights/5 Days</option>
                   <option value="5">5 Nights/6 Days</option>
                   <option value="6">6 Nights/7 Days</option>
                   <option value="7">7 Nights/8 Days</option>
                   <option value="8">8 Nights/9 Days</option>
                   <option value="9">9 Nights/10 Days</option>
                   <option value="10">10 Nights/11 Days</option>
                   <option value="11">11 Nights/12 Days</option>
                   <option value="12">12 Nights/13 Days</option>
                   <option value="13">13 Nights/14 Days</option>
                   <option value="14">14 Nights/15 Days</option>
                   <option value="15">More than 15 Days</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="row">
            <div class=" col-sm-6">
                <div class="form-group former">
                  <input type="text" name="date" readonly="" class="form-control"  id="datepicker2" required="true" placeholder="Travel Date">
                </div>
            </div>
            <div class=" col-sm-6">
                <div class="form-group former">
                  <!-- <input type="number" class="form-control" id="Adults" placeholder="No. of Adults"> -->
                   <select name="adult" class="form-control" id="adult" required="true" >
                    <option selected="selected" value="">No. of Adults</option>
                   <option value="1">01</option><option value="2">02</option><option value="3">03</option><option value="4">04</option><option value="5">05</option><option value="6">06</option><option value="7">07</option><option value="8">08</option><option value="9">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="Group">Group</option>
                  </select>
                </div>
            </div>
            </div>

            <div class="form-group">
              <textarea class="form-control former" id="message" placeholder="Your Message" name="message"></textarea>
            </div>

            <center><button type="submit" name="submit" class="btn btn-plan hvr-ripple-out">Submit</button>
            </center>
          </form>
        </div>
      </div>
   
  </div>
 
		</div>
		
		</div>
		<br>
<div class="myclass"> 
	<div class="myheading">
				<h5 class="colorb" >Simply Ladakh</h5>		
				<h5>05 Nights and 06 Days</h5>
				<h5> INR <span class="myline"> 32,032  </span> &nbsp 17,600   Onwards <span class="colorr">(45% off)</span> </h5>
				</div>       
<h2>Package Inclusions:</h2>		
<p>•	Leh : Gurudwara | Sangam | Pangong Lake | Spituk monestery | Hall of fame | Magnetic Hill Assistance</p>
<p> 
•	Nubra Valley : Khardungla Pass | Diskit monasteries 
</p>
<p>•	All Sightseeing as per itinerary by Innova Cab
</p>
<p>
•	All hotel and transport taxes.
</p>
<p>
•	pick up from Leh and drop at Leh by 01 Ac Innova
</p>
<p>
•	05 Nights Accommodation on double sharing basis with 05 Breakfast and 05 Dinner.
</p>
<p>•	Inner Line Permit.</p>

<h4>
Day 01:- Arrive Leh:
</h4>
<p>Early morning board flight to Leh. Upon arrival at the Leh Airport, you will be received by our driver and transferred to your hotel. Take lunch and relax. Since you are arriving at 11000 ft, we strongly recommend taking complete rest on the first day where you should not indulge yourself in any strenuous activity. Rest of the day is free to acclimatize to the high altitude of Leh. Lunch, Dinner & Overnight at hotel.
</p>
<h4>
Day 02 :-LEH – LOCAL SIGHTSEEING 
</h4>
<p>
After breakfast drive to explore the beauty of Shanti Stupa, Leh palace and market .
<strong>Shanti Stupa</strong>:- Shanti stupa was founded in 1985 sponsored by Japanese for world
peace. It was inaugurated by His holiness the 14th Dalai lama. Shanti stupa has a
spectacular view od Leh city and Stok glacier.
<strong>Leh Palace</strong>:-The Leh Palace known as ‘Lachen Palkhar’ was built by Singay Namgyal,
around the beginning of 17th century AD. The nine-storey Palace is now deserted, and
archeological survey of India has taken up the renovation work.Over night in hotel.
</p>
<h4>
DAY 03: LEH–NUBRA VALLEY VIA KHARDUNG LA 18,380 FT. (120
KMS / 4 – 5 HRS)
</h4>
<p> 
After breakfast we drive to Nubra Valley. The road journey from Leh to Nubra Valley
passes over <strong>Khardung La</strong> (The Highest Motorable Road In The World) at 5,602 Mtrs /
18,380 ft, around 39 km from Leh. From the pass, one can see all the way south over the
Indus valley to seemingly endless peaks and ridges of the Zanskar range, and north to
the giants of the Saser massif. Nubra Valley is popularly known as Ldumra or the valley
of flowers. It is situated in the north of Ladakh between the Karakoram and Ladakh
ranges of the Himalayas. The average altitude of the valley is 10,000 Ft. above sea level.
Upon arrival in Nubra we check in at our Camp / Hotel in Hunder for Overnight stay. In
the evening you can walk around the tiny villages to see how the locals live in this part
of the world. A visit to a Ladakhi home can be arranged. Overnight Stay at the Camp or
Hotel.
</p>
<h4>
DAY 04: NUBRA VALLEY – PANGONG LAKE – 13,930 FT. (275 KMS / 7- 8 HRS )
</h4>
<p> 
After Breakfast Full day trip, after early morning breakfast we leave for <strong>Pangong
Lake </strong> through <strong>Changla pass (17,586 ft) world third highest motorable road in the
world.</strong> After 2 hrs of drive you reach to Changla pass, stop for a short period for
photography. Drive ascending towards Pangong reach Tangtse where you can relax for
a cup of tea/ coffee. Leaving Tangtse for Pangong you pass through few small villages of
Changthang and finally you can have a sudden view of the Pangong lake situated at
13,930 feet. This famous high altitude Lake of Pangong is 5- 8Kms wide and over 140
Kms long with 30 % in India and 70% in China. This large, serene lake forms a brilliant
color variation including deep blue, dark green, turquoise,etc. Dinner and overnight in
camp.
</p>
<h4>
DAY 05: PANGONG LAKE TO LEH (180 KMS / 5-7 HRS)
</h4>
<p>
Morning at leisure to explore the beauty of lake and later we drive back to leh. Drive
further to Leh and check in at our hotel for Overnight.
In the evening you can stroll around the market place for some last minute souvenir
shopping.
</p>
<h4>
DAY 06: Departure from Leh:
</h4>
<p>
After breakfast, Depart to Leh airport to board the flight back for onward journey.
</p>
<br>
</div>		
      <div class="row">
        <div class="col-sm-12 myclass1">
          <h2 class="text-center">Popular Tours</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="magical-ladakh.php"><img class="img-fluid" src="images\packages\lehladakh2.jpg" alt="Magical ladakh"> <span>7N/8D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="magical-ladakh.php">Magical ladakh</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="magical-ladakh.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
		
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-bike.php"><img class="img-fluid" src="images\packages\lehladakh6.jpg" alt="Ladakh by Motor Bike"> <span>6N/7D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="ladakh-bike.php">Ladakh by Motor Bike</a></strong></h5>

            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-bike.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
		  
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="ladakh-with-tasomiriri.php"><img class="img-fluid" src="images\packages\lehladakh4.jpg" alt="Ladakh with tasomiriri"> <span>6N/7D</span> </a> </div>
           <div align="center" class="package-content">
              <h5><strong><a href="ladakh-with-tasomiriri.php">Ladakh with tasomiriri</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="ladakh-with-tasomiriri.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
        </div>
      
      <div class="col-md-3 col-sm-6">
          <div class="single-package">
            <div class="package-image"> <a href="magical-ladakh-road-trip.php"><img class="img-fluid" src="images\packages\lehladakh2.jpg" alt="Magical ladakh"> <span>7N/8D</span> </a> </div>
            <div align="center" class="package-content">
              <h5><strong><a href="magical-ladakh-road-trip.php">Ladakh with Road Trip</a></strong></h5>
            </div>
							<div class="packselect" align="center">             
							 <a href="magical-ladakh-road-trip.php" <button type="submit" class="btn btn-enq1 hvr-ripple-out">MORE DETAILS</button></a>
							</div>
          </div>
    </div>
     </div>
    </div>
    </div>
  <section id="moreinfo">
  <div class="container">
  <div class="row">
      <div class="col-lg-12">
      </div>
  </div>
  </div>
  </section>
  <!-- more ends-->

<?php include('footer.php');?>