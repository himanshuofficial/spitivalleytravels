<?php
if(isset($_POST['submit'])){
	
if($_POST["name"]==""||$_POST["email"]==""||$_POST["mobile"]==""){
 

}else{
 $name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['mobile'];
$city = $_POST['city'];
$destination = $_POST['destination'];
$formcontent="From: ".$name ."\n Email: ".$email ."\n Mobile: ". $message." \n City: ". $city."  \n destination: ". $destination.""; 
$recipient = "sales@himalayanfootslog.com,coolchanshal@gmail.com,himalayanfootslog@gmail.com";
$subject = "Contact Form";
$mailheader = "From:". $email." \r\n";
if(mail($recipient, $subject, $formcontent, $mailheader)){
	$msg = "Your Request successfully Submitted.";
}
}
} 
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Spiti Valley Travels</title>


<!--===========================main css for  web host page===============================-->

<link href="css/style.css" rel="stylesheet" type="text/css">

<!--=================================GOOGLE FONT - OPEN SANS==============================-->

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800' rel='stylesheet' type='text/css'>

<!--=============================jquery.js==============================-->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
.free-quotes .get-free {
    background: #f47a27;
    color: #fff;
    text-align: center;
    padding: 20px 0;
    font-size: 30px;
    position: relative;
}

.free-quotes .get-free-qoute {
    padding: 30px;
	background-color:white;
}
body{
font-family:768a1c;
}
</style>

</head>
<body>

<!--=============================Banner=============================-->

<section id="header">
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="logo">
                        <img src="images/logoo.png" alt="" class="ing-fluid" height="120px">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="text-center">
                        <a href="" style="margin-top:16px;padding: 13px;" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">Last Minute Deal</a>
                    </div>    
                </div>
                <div class="col-md-4">
                    <div class="head-cnt">
                        <ul>
                            <li><i class="fa fa-phone"></i><a href="tel: +91-8353010033">+91-8353010033 ,</a><a href="tel: +91-8353040008">+91-8353040008</a></li>
                            <li><i class="fa fa-envelope"></i> <a href="mailto:spitivalleytravels@gmail.com">  spitivalleytravels@gmail.com</a></li>
							<li><i class="fa fa-globe"></i><a href="www.spitivalleytravels.com" target="_blank">  www.spitivalleytravels.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </header>
</section>

<section id="banner">
        <div class="banner-warp">
            <div class="container">
                <div class="row">
                <div class="col-sm-4">
                        <div class="free-quotes">
                             <div class="get-free" id="Get-Free-Quote">Get Free Quote</div>
                                <div class="get-free-qoute">
                                  <form method="POST" name="myForm" action="" onsubmit="return validateForm()">
                                      <div class="form-group">
                                        <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" required>
                                      </div>

                                      <div class="form-group">
                                        <input type="email" name="email" class="form-control" id="exampleInputPassword1" placeholder="Email" required>
                                      </div>

                                      <div class="form-group">
                                        <input min="1" maxlength="10"  type="number" name="mobile" class="form-control input-empty" id="exampleInputPassword1" placeholder="Mobile No." required>
                                      </div>

                                      <div class="form-group">
                                        <input type="text" name="city" class="form-control" id="exampleInputPassword1" placeholder="Your City" required>
                                      </div>

                                      <div class="form-group">
                                        <select class="form-control" name="destination" id="destination" required>
										  <option selected disabled>Choose your Destination</option>
                                       
										    <option>LAHAUL SPITI -BIKE TOUR</option>
											  <option>UNEXPLORED SPITI</option>
											    <option>BHUDDIST AND TRIBAL CIRCUIT –SPITI</option>
												  <option>SPITI VALLEY WOMEN ONLY TOUR</option>
												  	   <option>SPITI VALLEY TOUR IN YOUR OWN CAR</option>
													  <option>HIDDEN HEAVEN- SPITI VALLEY</option>
                                        </select>
                                      </div> 
                                     <div class="text-center">
                                            <button type="submit" name="submit" class="btn btn-enq ">Send Enquiry</button>
                                        </div>      
                                    </form>
                                </div>
                        </div>
                    </div>
               
				    <div class="col-sm-8" style="text-align:right;>
                        <div class="banner-text">
                            <img src="images/sale-ico.png" alt="" class="img-fluid upto" >
                            <h1><strong>Spiti Valley Tour Packages</strong></h1>
                            <h4>Best Services Guaranted</h4>
                            
                            <ul class="trusted" style="text-align: left;">
                                 
                                <li>
                                   <i class="fa fa-check"></i>  Easy Booking
                                </li>
                                <li>
                                    <i class="fa fa-check"></i>  Reliable
                                </li>
								 <li>
                                    <i class="fa fa-check"></i> Instant Response
                                </li>
                               
                            </ul>
                            
                            
                        </div>
                    </div>
                    
			   </div>     
            </div>
            <div class="banner-2">
                <div class="container">
                     <div class="row">
                        <div class="col-md-12">
                            <ul>
                                <li>
                                    <div class="abt-cmpny">
                                        <figure>
                                            <img src="images/icon-1.png" alt="" class="img-fluid">
                                        </figure>
                                        <h6>Experienced Drivers<br>
                                            </h6>
                                    </div>
                                </li>
                                
                                
                                <li>
                                    <div class="abt-cmpny">
                                        <figure>
                                            <img src="images/icon-2.png" alt="" class="img-fluid">
                                        </figure>
                                        <h6>5 / 5 On Google Reviews<br>
                                            </h6>
                                    </div>
                                </li>
                                
                                
                                <li>
                                    <div class="abt-cmpny">
                                        <figure>
                                            <img src="images/icon-3.png" alt="" class="img-fluid">
                                        </figure>
                                        <h6>Approved By Himachal Tourism <br>
                                            </h6>
                                    </div>
                                </li>
                                
                                 <li>
                                    <div class="abt-cmpny">
                                        <figure>
                                            <img src="images/icon-4.png" alt="" class="img-fluid">
                                        </figure>
                                        <h6>Best Discounted Deals<br>
                                            </h6>
                                    </div>
                                </li>
                                                                
                               
                                
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>








<!--==============================Services=============================-->


<!--==============================Offer==============================-->




<!--==============================New Custom Slider end ============================-->


<div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="h1-global">Our Top Packages</h1>
                </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                            <img src="images/image004.jpg" alt="" class="img-fluid img-responsive">
                         <div class="tag">30% off </div>
                                <div class="budget">
                                 <img src="images/budget.png" alt="" class="img-fluid">
                            </div>
                            
                           
                            
                        </figure>
                        <h2>LAHAUL SPITI -BIKE TOUR</h2>
                        <h3>9N/10D / <span>01 nights Shimla | 01 night Sangla | 01 night Kalpa  | 01night Nako|1Night Mudh|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali| </span> </h3>
                        <ul class="itnry">
                          
                            
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>	Visit Sangla ,Kalpa ,Nako, pin valley, Dhankar,Gue mummy, Komic, Kibber, Ki – Monastery, Chandratal, Rohtang Pass. </li>
                                <li>	All Sightseeing as per itinerary by Bullet. </li>
								
								 
								
								
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample" style="">
                                <ul class="pkg-incusion">
									<li>09 Nights Accommodation on double sharing basis.</li>
									<li>1 backup cab with mechanic.</li>
                                   <li>Assistance on arrival</li>
									<li>09 Breakfasts & 09 Dinners.</li>
									<li>Pick and Drop at time of arrival/departure.</li>
									<li>Driver's allowance, Road taxes.</li>
									<li>All Sightseeing as per itinerary by Bullet</li>
									<li>All hotel and transport taxes</li>
									<li>09 Nights Accommodation on double sharing basis</li>
									<li>Portable oxygen cylinder and medical kit</li>
									

                                </ul>
                            </div>
                              <a class="read-collpse collapsed" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                  <span>Read More</span> 
                                   
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							 <small><i class="fa fa-rupee"></i>47,900 </small>
                                <i class="fa fa-rupee"></i> 36,900 Onwards 
                            </div>
                            <div class="btn-detail">
                                <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                                </div>
                        </div>
                    </div>
                </div>
              <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                            <img src="images/image006.jpg" alt="" class="img-fluid img-responsive">
                         <div class="tag">40% off </div>
						 <div class="budget">
                                 <img src="images/budget.png" alt="" class="img-fluid">
                            </div>
                        </figure>
                        <h2>UNEXPLORED SPITI</h2>
                        <h3>6N/7D / <span>01 night Sangla | 01night Nako|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali|</span> </h3>
                        
							     <ul class="itnry">
                           
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>Visit Sangla ,Nako, Dhankar,tabo ,Gue mummy, Komic, Kibber, Ki-Monastery, Chandratal, Rohtang Pass.</li>
                                <li>All Sightseeing as per itinerary by Private SUV. </li>
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample2">
                                <ul class="pkg-incusion">
                                    <li>Assistance on arrival.</li>
									<li>06 Breakfasts & 06 Dinners.</li>
									<li>Pick and Drop at time of arrival/departure.</li>
									<li>Driver's allowance, Road tax and Fuel charges.</li>
									<li>All Sightseeing as per itinerary by Bullet.</li>
									<li>All hotel and transport taxes & Driver Allowances.</li>
									<li>All transfers and sightseeing by personal car.</li>
									<li>06 Nights Accommodation on double sharing basis.</li>
									<li>Portable oxygen cylinder and medical kit.</li>
									
                                </ul>
                            </div>
                              <a class="read-collpse" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                                <span>Read More</span> 
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							  <small><i class="fa fa-rupee"></i>23,700</small>
                                <i class="fa fa-rupee"></i> 16,900 Onwards  
                            </div>
                            <div class="btn-detail">
                               <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                                </div>
                        </div>
                    </div>
                </div>
              <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                             <img src="images/image008.jpg" alt="" class="img-fluid img-responsive">
                            <div class="tag">50% OFF</div>
							<div class="budget">
                                 <img src="images/budget.png" alt="" class="img-fluid">
                            </div>
                        </figure>
                        <h2>BHUDDIST AND TRIBAL CIRCUIT –SPITI</h2>
                        <h3>10N/11D / <span>01 night Shimla | 01night Sarahan|01night Sangla | 01 night Kalpa | 01night Nako|1Night Mudh|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali| </span> </h3>
                        
						    <ul class="itnry">
                           
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>Visit Shimla Mall-road ,Sarahan Temple, Sangla, Kalpa ,Nako, Pin- valley, Dhankar, tabo ,Gue mummy, Komic, Kibber, Ki-Monastery, Chandratal, Rohtang Pass. </li>
                                <li>Assistance on arrival.</li>
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample3">
                                <ul class="pkg-incusion">
                                   
								<li>10 Breakfasts & 10 Dinners.</li>
								<li>Pick and Drop at time of arrival/departure.</li>
								<li>Driver's allowance, Road tax and Fuel charges.</li>
								<li>All Sightseeing as per itinerary by Private SUV. </li>
								<li>All hotel and transport taxes & Driver Allowances.</li>
								<li>All transfers and sightseeing by personal car.</li>
								<li>10 Nights Accommodation on double sharing basis.</li>
								<li>Portable oxygen cylinder and medical kit.</li>

                                </ul>
                            </div>
                              <a class="read-collpse" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample3">
                                <span>Read More</span> 
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							 <small><i class="fa fa-rupee"></i>35,900 </small>
                                <i class="fa fa-rupee"></i> 23,900 Onwards  
                            </div>
                            <div class="btn-detail">
                              <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <hr>
				<div class="row">
                <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                             <img src="images/image010.jpg" alt="" class="img-fluid img-responsive">
                           <div class="tag">40% OFF</div>
							<div class="budget">
                                <img src="images/popular.png" alt="" class="img-fluid">
                            </div>
                        </figure>
                        <h2>SPITI VALLEY WOMEN ONLY TOUR</h2>
                        <h3>9N/10D / <span>01 night Shimla | 01night Sangla | 01 night Kalpa | 01night Nako|1Night Mudh|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali|</span> </h3>
                        
						    <ul class="itnry">
                           
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>Visit Sangla, Kalpa ,Nako, Pin- valley, Dhankar, Tabo ,Gue mummy, Komic, Kibber, Ki-Monastery, Chandratal, Rohtang Pass.</li>
                                <li>Assistance on arrival.</li>
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample4">
                                <ul class="pkg-incusion">
                                     
								<li>09 Breakfasts & 09 Dinners.</li>
								<li>Pick and Drop at time of arrival/departure.</li>
								<li>Driver's allowance, Road tax and Fuel charges.</li>
								<li>All Sightseeing as per itinerary by Private SUV. </li>
								<li>All hotel and transport taxes & Driver Allowances.</li>
								<li>All transfers and sightseeing by personal car.</li>
								<li>09 Nights Accommodation on double sharing basis. </li>
								<li>Portable oxygen cylinder and medical kit.</li>
								

                                </ul>
                            </div>
                              <a class="read-collpse" data-toggle="collapse" href="#collapseExample4" role="button" aria-expanded="false" aria-controls="collapseExample4">
                                 <span>Read More</span> 
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							      <small><i class="fa fa-rupee"></i>27800</small>
                                <i class="fa fa-rupee"></i> 19,900 Onwards 
                            </div>
                            <div class="btn-detail">
                              <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                                </div>
                        </div>
                    </div>
                </div>
              <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                             <img src="images/image012.jpg" alt="" class="img-fluid img-responsive">
                            <div class="tag">40% OFF</div>
							<div class="budget">
                                   <img src="images/popular.png" alt="" class=" img-responsive">
                            </div>
                        </figure>
                        <h2>SPITI VALLEY TOUR IN YOUR OWN CAR</h2>
                        <h3> 10N/11D / <span>01 night Narkanda| 01night Sarahan|01night Sangla | 01 night Reckong - Peo | 01night Nako|1Night Mudh|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali|</span> </h3>
                        
						    <ul class="itnry">
                           
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                       
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>Visit Sangla, Kalpa ,Nako, Pin- valley, Dhankar, Tabo ,Gue mummy, Komic, Kibber, Ki-Monastery, Chandratal, Rohtang Pass. </li>
                                <li>Assistance on arrival.</li>
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample5" style="">
                                <ul class="pkg-incusion">
                                    
								<li>10 Breakfasts & 10 Dinners.</li>
								<li>Proper assistance with itinerary.</li>
								<li>All hotel taxes.</li>
								<li>10 Nights Accommodation on double sharing basis.</li>
								<li>Portable oxygen cylinder and medical kit.</li>
								

                                </ul>
                            </div>
                              <a class="read-collpse collapsed" data-toggle="collapse" href="#collapseExample5" role="button" aria-expanded="false" aria-controls="collapseExample5">
                                 <span>Read More</span> 
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							    <small><i class="fa fa-rupee"></i>20800</small>
                                <i class="fa fa-rupee"></i>  14,900 Onwards 
                            </div>
                            <div class="btn-detail">
                             <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                                </div>
                        </div>
                    </div>
                </div>
              <div class="col-md-4">
                    <div class="packages">
                        <figure>
                            <div class="overlay"></div>
                             <img src="images/image014.jpg" alt="" class="img-fluid img-responsive">
                            <div class="tag">40% OFF</div>
							<div class="budget">
                                  <img src="images/popular.png" alt="" class="img-fluid">
                            </div>
                        </figure>
                        <h2>HIDDEN HEAVEN- SPITI VALLEY</h2>
                        <h3>8N/9D / <span>01night Sangla | 01 night Reckong - Peo | 01night Nako|1Night Mudh|1Night Kaza |1Night Langza| 01 night Chandratal |01 night Manali| </span> </h3>
                            <ul class="itnry">
                           
                            <li>
                                <figure>
                                    <img src="images/hotel-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Hotels</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/Sightseeing-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Sightseeing</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/meals-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Meals</p>
                            </li>
                            
                            <li>
                                <figure>
                                    <img src="images/transfer-icon.png" alt="" class="img-fluid">
                                </figure>
                                <p>Transfers</p>
                            </li>
                            
                        </ul>
                     
                        
                       
                        
                        <div class="inclusions">
                            <h5>Package Inclusions:</h5>
                            
                            <ul class="pkg-incusion">
                                <li>Visit Sangla, Kalpa ,Nako, Pin- valley, Dhankar, Tabo ,Gue mummy, Komic, Kibber, Ki-Monastery, Chandratal, Rohtang Pass. </li>
                                <li>Assistance on arrival.</li>
                            </ul>
                            
                            
                            <div class="collapse" id="collapseExample6">
                                <ul class="pkg-incusion">
                                    
								<li>08 Breakfasts & 08 Dinners.</li>
								<li>Pick and Drop at time of arrival/departure.</li>
								<li>Driver's allowance, Road tax and Fuel charges.</li>
								<li>All Sightseeing as per itinerary by Private SUV. </li>
								<li>All hotel and transport taxes & Driver Allowances.</li>
								<li>All transfers and sightseeing by personal car.</li>
								<li>08 Nights Accommodation on double sharing basis.</li>
								<li>Portable oxygen cylinder and medical kit.</li>
								

                                </ul>
                            </div>
                              <a class="read-collpse" data-toggle="collapse" href="#collapseExample6" role="button" aria-expanded="false" aria-controls="collapseExample6">
                                 <span>Read More</span> 
                                    <!-- <i>Close </i> -->
                              </a> 
                        </div>
                        
                        
                        <div class="price-tag">
                            <div class="price">
							  <small><i class="fa fa-rupee"></i> 25,500</small>
                                <i class="fa fa-rupee"></i> 18,200 Onwards 
                            </div>
                            <div class="btn-detail">
                             <a href="" class="btn btn-detail" data-toggle="modal" data-target="#exampleModalLong">Get More Info</a>
                                </div>
                        </div>
                    </div>
                </div>
				</div>
                <hr>
	 </div>

		<section id="confused">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="h1-global white-color">Still <span class="white-color">Confused ?</span></h1>
					   
                    <a href="" class="btn requirement" data-toggle="modal" data-target="#exampleModalLong">Click &amp; Let Us Know Your Requirement</a>
                </div>
            </div>
        </div>
    </section>
		
		
		
<div class="package-container">
  <div class="container">
    <div class="row main-head">
      <div class="col-md-12">
        <h1>Why choose our packages</h1>
        
       
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 col-md-6 " >
        <div class="package1"> <img src="images/dhanker.jpg" alt=""> </div>
      </div>
      <div class="col-sm-12 col-md-6 package-text-area" >
        <div class="package"> <span class="packageIcon"></span>
          <h2>Value for Money And Easy Booking</h2>
          <p>At Himalayan Footslog, we always thrive to offer our clients more than what they desire for. Our easy booking facility allows you to book your favourite holiday in the least possible time. Our packages are designed in such a way that you get the best facilities at affordable rates.</p>
        </div>
        <div class="package"> <span class="packageIcon"></span>
          <h2>Reliability & Instant Response</h2>
          <p>Himalayan Footslog has been active in this domain long enough to know our clients requirements well. Our highly experienced team have full knowledge about various tourist destinations and perks attached to it. Our choices of the Hotels, Resorts or Campsites are highly picturesque, with full exposure of the wild. </p>
        </div>
        <div class="package"> <span class="packageIcon"></span>
          <h2>Diverse Destinations & Beautiful Places</h2>
          <p>Himalayan Footslog believes in how you actually look at travelling. Himalayan Footslog takes regular initiatives in discovering new trekking trails or discovering new tourist destinations, keeping in mind the most important factor, safety of our clients. Our choice of the expedition is the most alluring and exhilarating that each trek unfolds new mystery.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!--==============================Footer============================-->
<section id="footer">
        <div class="container-fluid">
                              
           <div class="row">
                <div class="col-md-12">
                    <ul class="ftr-link">
                        <li>Himachal</li>
                        <li>Spiti Valley</li>
                        <li>Ladakh</li>
                       
                        <li>Rajasthan</li>
 
                        <li>Kerala</li>
                    </ul>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-5 hidden-md">
				          
                  <h4 class="ftr-h4">About Us</h4>
<h5 class="ftr-h5">We are a small company based in Shimla(H.P.) which delivers outstanding adventure travel experiences. <h5> 
				  <h4 class="ftr-h4">Spiti Valley Travels</h4>

<h5 class="ftr-h5">Ground Floor, Mehta Villa, Upper Khalini Chowk, Shimla, Himachal Pradesh.

Approved by Government of Himachal Pradesh, Department of tourism.</h5>

                </div>
				

               
                
                 <!--<div class="col-md-3">
                    <h4 class="ftr-h4"></h4>
                    <div class="approved">
                        <img src="images/logos.png" alt="" class="img-fluid">
                    </div>  
                </div>-->
                
                 <div class="col-md-7">
                   <h4 class="ftr-h4">We Accept All Major Credit And Debit Cards</h4>
                    <div class="approved">
                      <a href="http://www.himalayanfootslog.com/pay-online/"><img src="images/payment.png" alt="" class="img-fluid"></a>
                        
                        
                        
                    <ul class="ftr-cnt">
                        <li><i class="fa fa-mobile"></i>  Mobile Operations: <a href="tel: +91-8353010033"> +91-8353010033</a>, <a href="tel: +91-8353040008">+91-8353040008</a> </li>
						<li><i class="fa fa-phone"></i>  Landline: <a href="tel: 0177-2627252"> 0177-2627252</a></li>
                        <li><i class="fa fa-envelope"></i>  Email: <a href="mailto:spitivalleytravels@gmail.com">spitivalleytravels@gmail.com</a></li> 
					    <li><i class="fa fa-globe"></i>  Website: <a href="www.spitivalleytravels.com" target="_blank"> www.spitivalleytravels.com</a></li>
						<li><i class="fa fa-credit-card"></i>GSTIN - 02AAKFH9802R1ZW </li>							
                        <li><i class="fa fa-id-card-o"></i>PAN NO – AAKFH9802R </li>							
                        <li><i class="fa fa-id-card-o"></i>Registration No. 11-1088/17-DTO-SML-1903 </li>	
						
                    </ul>    
                    </div>
                </div> 
            </div>
			<div class="mobile-footer">     
  
            </div>  
        </div>
    </section>
	
	<style>
	.whtapp-icon {
	position: fixed;
	background: #4ec95c;
	bottom: 12%;
	/* left: 50%; */
	z-index: 99999999999;
	border-radius: 50%;
	height:50px;
	width: 50px;
}
.whtapp-box i {
	/* background: #000; */
	/* z-index: 99999999999; */
	margin-left: 16px;
	font-size: 24px;
	margin-top: 11px;
	color: #fff;
}
	</style>
    
    
    <div class="whtapp-icon hidden-lg hidden-md">
          <div class="whtapp-box"> <a class="" href="https://wa.me/918353010033?text=I'm%20interested%20in%20your%20package"><i class="fa fa-whatsapp"></i>
</a> </div>
		  
        </div>


<div class="section_mobile">
  <div class="inner_mobile">
    <div class="container-fluid">
      <div class="col-md-12">
        <div class="col-md-3 p-0 col-3 col-xs-3">
          <div class="_col_m"> <a class="_btn_bm" href="tel:+91-7591801490"> <i class="fa fa-phone fa-1x"></i></a> </div>
		  
        </div>
		
        <div class="col-md-9 p-0 col-xs-6">
          <div class="_col_bm">
            <button type="button" class="_btn_bm" data-toggle="modal" data-target="#exampleModalLong"  style="font-size: 16px;color: #000 ;">SEND ENQUIRY</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
	
				
<!-- Modal -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="row">
       <div class="col-md-10">
          <div class="free-quotes">
                             <div class="get-free" id="Get-Free-Quote">Get Free Quote</div>
                                <div class="get-free-qoute">
                                  <form method="POST" name="myForm" action="" onsubmit="return validateForm()">
                                      <div class="form-group">
                                        <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" required>
                                      </div>

                                      <div class="form-group">
                                        <input type="email" name="email" class="form-control" id="exampleInputPassword1" placeholder="Email" required>
                                      </div>

                                      <div class="form-group">
                                        <input type="text" name="mobile" class="form-control" id="exampleInputPassword1" placeholder="Mobile No." required>
                                      </div>

                                      <div class="form-group">
                                        <input type="text" name="city" class="form-control" id="exampleInputPassword1" placeholder="Your City" required>
                                      </div>

                                      <div class="form-group">
                                        <select class="form-control" name="destination" id="destination" required>
										  <option selected disabled>Choose your Destination</option>
                                     
										    <option>LAHAUL SPITI -BIKE TOUR</option>
											  <option>UNEXPLORED SPITI</option>
											    <option>BHUDDIST AND TRIBAL CIRCUIT –SPITI</option>
												  <option>SPITI VALLEY WOMEN ONLY TOUR</option>
												  	   <option>SPITI VALLEY TOUR IN YOUR OWN CAR</option>
													  <option>HIDDEN HEAVEN- SPITI VALLEY</option>
                                        </select>
                                      </div> 
                                     <div class="text-center">
                                            <button type="submit" name="submit" class="btn btn-enq ">Send Enquiry</button>
                                        </div>      
                                    </form>
                                </div>
                        </div>
					</div>
        
      </div>
  </div>
</div>
<?php if(isset($msg)) {?>

<!-- Google Code for spiti tour Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 858815337;
var google_conversion_label = "c5HpCMOf3ocBEOn2wZkD";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript"  
src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt=""  
src="//www.googleadservices.com/pagead/conversion/858815337/?label=c5HpCMOf3ocBEOn2wZkD&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
<?php } ?>


	  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
     <div class="alert alert-success">
 <strong>Success!</strong> <?php echo $msg; ?>
  </div>
      
    </div>
  </div>
 
<!--============================Main.js===========================--> 

<script src="js/main.js" type="text/javascript"></script> 


  <!--Start of Tawk.to Script-->
  
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c8791c9101df77a8be227c9/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
  

</body>
</html>
