<?php $name = $_POST['name'];
$email = 'ravi';
$message = '8528907107';
$formcontent="From: $name \n Message: $message";
$recipient = "33infotech@gmail.com";
$subject = "Contact Form";
$mailheader = "From: $email \r\n";
if(mail($recipient, $subject, $formcontent, $mailheader)){echo "Thank You!";}


?>