$(function(){

	var monthSliderSpeed = 700,
		inline_block_adjust = 4,
		monthsToScroll = 3;

	$('.catalog .trek').click(function(){
		var link = $(this).attr('data-href');
		if(link) window.location = link;
	});
	
	/* Takes url from Slider .item<img and puts it on .item for display on mobile devices */
	$('.carousel-inner > .item > img').each(function(){
		var imageURL = $(this).attr('src');
		$(this).parent('.item').css('backgroundImage','url('+imageURL+')');
	});	

	/* Month Slider on Fixed Departures page*/

	/* Slider Right Button */
	function rightButton(e){
		var li_width = $('.month-list .list-container ul li').outerWidth(true)+inline_block_adjust,
			left_pos = parseInt($('.month-list .list-container ul').css('left')),
			list_width = $('.month-list .list-container').width(),
			ul_width = $('.month-list .list-container ul').width();
		if(-left_pos+list_width < ul_width){
			$(e.target).off('click');
			$('.month-list .list-container ul').animate({left:'-='+(monthsToScroll*li_width)},monthSliderSpeed,function(){
				$(e.target).on('click', rightButton);
			});
		}
	}
	$('.month-list .fa-chevron-right').on('click',rightButton);

	/* Slider Left Buton */
	function leftButton(e){
		var li_width = $('.month-list .list-container ul li').outerWidth(true)+inline_block_adjust,
			left_pos = parseInt($('.month-list .list-container ul').css('left')),
			ul_width = $('.month-list .list-container ul').width();
		if(left_pos<0){
			$(e.target).off('click');
			$('.month-list .list-container ul').animate({left:'+='+(monthsToScroll*li_width)},monthSliderSpeed,function(){
				$(e.target).on('click', leftButton);
			});
		}
	}
	$('.month-list .fa-chevron-left').on('click',leftButton);

	$('.brief-itin li').click(function(){
		let numChild = $(this).index()
		let dayNum = $('.day-container .day').eq(numChild);
		let offSet = $(dayNum).position().top;
		$('.brief-itin li').removeClass('active');
		$(this).addClass('active');
		$('.day-container').animate({scrollTop: offSet + $('.day-container').scrollTop()});
	});

	$('#wtp-accordion .panel-heading a').click(function() {
		$('#wtp-accordion .panel-heading').removeClass('actives');
		$(this).parents('.panel-heading').addClass('actives');
	});

	$('#saf-accordion .panel-heading a').click(function() {
		$('#saf-accordion .panel-heading').removeClass('actives');
		$(this).parents('.panel-heading').addClass('actives');
	});

	$('.invoke-form').click(function(){
		var marTop = $(window).scrollTop() + 30;
		$('.query-modal').css('marginTop',marTop);
		$('.query-container').fadeIn();
		$(document).keyup(function(e) {
		    if (e.keyCode == 27) { 
		    	$('.query-container').fadeOut();
		    }
		});
	});

	$('.invoke-dl-form').click(function(){
		var marTop = $(window).scrollTop() + 30;
		$('.dl-query-modal').css('marginTop',marTop);
		$('.dl-query-container').fadeIn();
		$(document).keyup(function(e) {
		    if (e.keyCode == 27) { 
		    	$('.dl-query-container').fadeOut();
		    }
		});
	});

	$('.query-modal .close-modal').click(function(){
		$('.query-container').fadeOut();
	});

	$('.dl-query-modal .close-modal').click(function(){
		$('.dl-query-container').fadeOut();
	});

	$('.query-modal .box .checkbox i').hover(
		function(){$(this).next().show();},
		function(){$(this).next().hide();}
	);

	$('.datepicker').datepicker({
    format: 'dd/mm/yyyy'
  }).on('changeDate', function (ev) {
    $(this).datepicker('hide');
  });

  $(".sendquery").click(function(event){
    event.preventDefault();
    $(".query-container").show();
  });

  $("#sendquery").submit(function(event){
    event.preventDefault();
    $.post($(this).attr("action"),$(this).serialize(),function(){

    }).done(function(res){
      if(res.status=='success')
      {
        $(".query-container").hide();
        alert(res.message);
      }
      else
      {
        alert(res.message);
       }
    });
    //$(this).reset();
    
  });

  // $(".close-modal").click(function(event){
  //   $(".query-container").hide();
  // });
  
  $('.view-full-btn').click(function(){
  	$('.full-itinerary').css('right',0);
  	$('.dialog-overlay').fadeIn();
  	$('html').css('overflow-y','hidden');
  	$(document).keyup(function(e) {
	    if (e.keyCode == 27) { 
	    	onCloseDialog();
	    }
	});
  });

  function onCloseDialog(){
  	$('.full-itinerary').css('right','-100%');
  	$('.dialog-overlay').fadeOut();
  	$('html').css('overflow-y','auto');
  }

  $('.close-dialog').click(onCloseDialog);
  $('.dialog-overlay').click(onCloseDialog);

});

$(window).load(function(){
	
	var pageOffset = $('.hero-slider').outerHeight()||50,
		$window = $(window),
		navbar_height = $('.navbar').outerHeight(),
		tabsOffset,tabHeaderHeight;
		if($('.trip-tabs').length) {
			tabsOffset = $('.trip-tabs').offset().top,
			tabHeaderHeight = $('.trip-tabs').outerHeight();
		}
	
	$window.scroll(function() {
		// Nav slides down when scrolling below hero-slider
	    if ( $window.scrollTop() >= pageOffset ) {
	        $('.navbar').addClass('scroll-nav');
	        $('.navbar>div').addClass('container');
	        $('.navbar>div').removeClass('container-fluid');
	    }
	    else if($window.scrollTop() < pageOffset) {
	    	$('.navbar').removeClass('scroll-nav');
	    	$('.navbar').css('transform','translateY(0px)');
	    	$('.navbar>div').addClass('container-fluid');
	      $('.navbar>div').removeClass('container');
	    }
	    // Trip tabs to stick to top and replace Navigation
	    /*if($('.trip-tabs').length) {
			if($window.scrollTop() > (tabsOffset-navbar_height)){
		    	let effectiveOffset = (tabsOffset-navbar_height) - $window.scrollTop();
		    	$('.navbar').css('transform','translateY('+effectiveOffset+'px)');
		    }
		    if($window.scrollTop() > tabsOffset){
	    		$('.trip-tabs').addClass('fixed');
	    		$('.trip-tabs').next().css('marginTop',tabHeaderHeight);
	    	}
	    	
	    	else if($window.scrollTop() < tabsOffset){
	    		$('.trip-tabs').removeClass('fixed');
	    		$('.trip-tabs').next().css('marginTop',0);
	    	}
			}*/
	});	
	
});